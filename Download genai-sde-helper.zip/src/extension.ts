
import * as vscode from 'vscode';
import axios from 'axios';

const apiBase = 'http://localhost:8080/genai';

async function callGenAI(endpoint: string, prompt: string, language = 'markdown') {
    try {
        const response = await axios.post(`${apiBase}/${endpoint}`, { query: prompt });
        const content = response.data.result || JSON.stringify(response.data, null, 2);
        const doc = await vscode.workspace.openTextDocument({ content, language });
        vscode.window.showTextDocument(doc);
    } catch (err: any) {
        vscode.window.showErrorMessage(`GenAI Error: ${err.message}`);
    }
}

export function activate(context: vscode.ExtensionContext) {
    const commands = [
        { cmd: 'requirementAnalysis', title: 'Requirement Analysis', endpoint: 'requirement' },
        { cmd: 'codeGeneration', title: 'Generate Code', endpoint: 'code' },
        { cmd: 'generateTests', title: 'Generate Test Cases', endpoint: 'test' },
        { cmd: 'reviewCode', title: 'Code Review Suggestions', endpoint: 'review' },
        { cmd: 'generateCICD', title: 'Generate CI/CD Pipeline', endpoint: 'cicd' },
        { cmd: 'generatePRSummary', title: 'Generate PR Summary', endpoint: 'pr-summary' }
    ];

    for (const { cmd, title, endpoint } of commands) {
        const disposable = vscode.commands.registerCommand(`genaiSdeHelper.${cmd}`, async () => {
            const input = await vscode.window.showInputBox({ prompt: `Enter input for ${title}` });
            if (!input) return;
            vscode.window.withProgress(
                { location: vscode.ProgressLocation.Notification, title: `${title} in progress...`, cancellable: false },
                () => callGenAI(endpoint, input)
            );
        });
        context.subscriptions.push(disposable);
    }
}

export function deactivate() {}
